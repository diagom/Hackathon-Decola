package com.rgm_19181914.execiciodatabase.Dominio.entidades;

public class Cliente {

    public int codigo;
    public String TipoPedido, NomePedido,valorPedido;



}
