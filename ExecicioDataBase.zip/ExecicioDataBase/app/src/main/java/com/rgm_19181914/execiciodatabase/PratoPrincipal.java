package com.rgm_19181914.execiciodatabase;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.snackbar.Snackbar;
import com.rgm_19181914.execiciodatabase.Dados.BancoDados;
import com.rgm_19181914.execiciodatabase.Dominio.Repositorio.ClienteRepositorio;
import com.rgm_19181914.execiciodatabase.Dominio.entidades.Cliente;

public class PratoPrincipal extends AppCompatActivity {


    private RadioButton lazanha, rosbife, fejoada;
    private SQLiteDatabase conexao;
    private BancoDados bancodados;
    public Button resgistrar, voltar;
    public ConstraintLayout layoutPratoP;


    Cliente cliente = new Cliente();
    ClienteRepositorio clienteRepositorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prato_principal);

        lazanha =(RadioButton) findViewById(R.id.RBPrato1);
        rosbife =(RadioButton) findViewById(R.id.RBPrato2);
        fejoada =(RadioButton) findViewById(R.id.RBPrato3);



        resgistrar =(Button) findViewById(R.id.BTNRegistrar);
        voltar = (Button) findViewById(R.id.BTNVoltar);
        layoutPratoP = (ConstraintLayout)findViewById(R.id.layoutPratoP);

        criarConecxao();
    }


    public void Cadastrar(View v){
        if (lazanha.isChecked()){
            cliente.TipoPedido="Prato Principal";
            cliente.NomePedido="Lazanha";
            cliente.TipoPedido= "100.0";
        }else if (rosbife.isChecked()){
            cliente.TipoPedido="Prato Principal";
            cliente.NomePedido="rosbife";
            cliente.TipoPedido= "150.0";
        }else if (fejoada.isChecked()){
            cliente.TipoPedido="Prato Principal";
            cliente.NomePedido="fejoada";
            cliente.TipoPedido= "200.0";
        }

        comfirmar();


    }

    public void onClick(View view) {
        Class classe=null;
        switch (view.getId()){
            case R.id.BTNVoltar: classe=MainActivity.class;break;

        }
        if (classe != null){
            Intent my = new Intent(getApplicationContext(),classe);
            startActivity(my);
        }

    }

    private void criarConecxao(){
        try{
            bancodados = new BancoDados(this);

            conexao = bancodados.getWritableDatabase();

            Snackbar.make(layoutPratoP,"Conexão Criada Com suceso!",Snackbar.LENGTH_LONG).setAction("ok",null).show();

            ClienteRepositorio clienteRepositorio = new ClienteRepositorio(conexao);

        }catch (SQLException ex){
            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("",null);
            dlg.show();
        }
    }
    public void comfirmar(){
        try{
            clienteRepositorio.IncerirPratos(cliente);
            finish();
        }catch (SQLException ex){
            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("",null);
            dlg.show();
        }


    }

}


