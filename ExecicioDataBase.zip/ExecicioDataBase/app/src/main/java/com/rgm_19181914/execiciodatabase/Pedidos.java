package com.rgm_19181914.execiciodatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Pedidos extends AppCompatActivity {


    public Button resgistrar, voltar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedidos);


        voltar = (Button) findViewById(R.id.BTNVoltar);
    }

    public void onClick(View view) {
        Class classe=null;
        switch (view.getId()){
            case R.id.BTNVoltar: classe=MainActivity.class;break;

        }
        if (classe != null){
            Intent my = new Intent(getApplicationContext(),classe);
            startActivity(my);
        }

    }
}
