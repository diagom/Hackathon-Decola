package com.rgm_19181914.execiciodatabase.Dominio.Repositorio;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.rgm_19181914.execiciodatabase.Dominio.entidades.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteRepositorio {

    private SQLiteDatabase conexao;

    public static String numeroMesa ;

    public ClienteRepositorio(SQLiteDatabase conexao){
        this.conexao = conexao;

    }


public void IncerirPratos(Cliente cliente){

    ContentValues contentValues =  new ContentValues();

        contentValues.put("MESA",         numeroMesa);
        contentValues.put("NOMEPEDIDO",   cliente.NomePedido);
        contentValues.put("TIPPEDIDO",    cliente.TipoPedido);
        contentValues.put("VALORPEDIDO",  cliente.valorPedido);

        conexao.insertOrThrow("PEDIDOMESA",null,contentValues);

}

public Cliente buscarMesa(int mesa){

        Cliente clientes = new Cliente();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CODIGO, MESA, NOMEPEDIDO, TIPOPEDIDO,VALORPEDIDO");
        sql.append(" FROM PEDIDOFECHADO ");
        sql.append(" WHERE MESA = ?");

        String[] parametros = new String[1];
        parametros[0] = String.valueOf(mesa);

        Cursor resultado = conexao.rawQuery(sql.toString(),parametros);


        if(resultado.getCount() > 0){

            resultado.moveToFirst();



            clientes.codigo = resultado.getInt(resultado.getColumnIndexOrThrow("CODIGO"));
            clientes.valorPedido = resultado.getString(resultado.getColumnIndexOrThrow("VALORPEDIDO"));
            numeroMesa = resultado.getString(resultado.getColumnIndexOrThrow("MESA"));
            clientes.NomePedido = resultado.getString(resultado.getColumnIndexOrThrow("NOMEPEDIDO"));
            clientes.TipoPedido = resultado.getString(resultado.getColumnIndexOrThrow("TIPOPEDIDO"));

            return clientes;
        }

        return null;

    }

public void excluir(int codigo  ){


    String[] parametros = new String[1];
    parametros[0] = String.valueOf(codigo);


    conexao.delete("PEDIDOMESA","codigo = ?",parametros);


}

public void alterar(Cliente cliente){
    ContentValues contentValues =  new ContentValues();

    contentValues.put("MESA",         numeroMesa);
    contentValues.put("NOMEPEDIDO",   cliente.NomePedido);
    contentValues.put("TIPOPEDIDO",    cliente.TipoPedido);
    contentValues.put("VALORPEDIDO",  cliente.valorPedido);

    String[] parametros = new String[1];
    parametros[0] = String.valueOf(cliente.codigo);




    conexao.update("PEDIDOMESA",contentValues,"codigo = ?",parametros);


}

public List<Cliente> pesquizar(Cliente cliente){
        List<Cliente> clientes = new ArrayList<Cliente>();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CODIGO, MESA, NOMEPEDIDO, TIPOPEDIDO,VALORPEDIDO");
        sql.append(" FROM PEDIDOFECHADO ");



        Cursor resultado = conexao.rawQuery(sql.toString(),null);

        if(resultado.getCount() > 0){

        resultado.moveToFirst();

        do{
            Cliente cli = new Cliente();

            cli.codigo = resultado.getInt(resultado.getColumnIndexOrThrow("CODIGO"));
            cli.valorPedido = resultado.getString(resultado.getColumnIndexOrThrow("VALORPEDIDO"));
            numeroMesa = resultado.getString(resultado.getColumnIndexOrThrow("MESA"));
            cli.NomePedido = resultado.getString(resultado.getColumnIndexOrThrow("NOMEPEDIDO"));
            cli.TipoPedido = resultado.getString(resultado.getColumnIndexOrThrow("TIPOPEDIDO"));

        }while(resultado.moveToNext());

        }


    return clientes;
}

public Cliente buscarMesaFechado(int mesa){

        Cliente clientes = new Cliente();

    StringBuilder sql = new StringBuilder();
    sql.append("SELECT CODIGO, MESA, NOMEPEDIDO, TIPOPEDIDO,VALORPEDIDO");
    sql.append(" FROM PEDIDOFECHADO ");
    sql.append(" WHERE MESA = ?");

    String[] parametros = new String[1];
    parametros[0] = String.valueOf(mesa);

    Cursor resultado = conexao.rawQuery(sql.toString(),parametros);


    if(resultado.getCount() > 0){

        resultado.moveToFirst();



            clientes.codigo = resultado.getInt(resultado.getColumnIndexOrThrow("CODIGO"));
            clientes.valorPedido = resultado.getString(resultado.getColumnIndexOrThrow("VALORPEDIDO"));
            numeroMesa = resultado.getString(resultado.getColumnIndexOrThrow("MESA"));
            clientes.NomePedido = resultado.getString(resultado.getColumnIndexOrThrow("NOMEPEDIDO"));
            clientes.TipoPedido = resultado.getString(resultado.getColumnIndexOrThrow("TIPOPEDIDO"));

        return clientes;
    }

    return null;

}

public void GerarFecharPedido(Cliente cliente,int mesa){



        ContentValues contentValues =  new ContentValues();

        contentValues.put("MESA",         numeroMesa);
        contentValues.put("NOMEPEDIDO",   cliente.NomePedido);
        contentValues.put("TIPOPEDIDO",    cliente.TipoPedido);
        contentValues.put("VALORPEDIDO",  cliente.valorPedido);

        conexao.insertOrThrow("PEDIDOFECHADO",null, contentValues);

        String[] parametros = new String[1];
        parametros[0] = String.valueOf(mesa);


        conexao.delete("PEDIDOMESA","mesa = ?",parametros);

    }


}
