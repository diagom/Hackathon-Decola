package com.rgm_19181914.execiciodatabase.Dados;

public class Scripts {

    public static String getCrietePedido() {

        StringBuilder sql = new StringBuilder();


        sql.append("CREATE TABLE IF NOT EXISTS PEDIDOMESA(");
        sql.append("CODIGO         INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,  ");
        sql.append("MESA           VARCHAR (15) NOT NULL DEFAULT('0') ,  ");
        sql.append("NOMEPEDIDO     VARCHAR (70) NOT NULL DEFAULT('')  ,  ");
        sql.append("TIPOPEDIDO      VARCHAR (70) NOT NULL DEFAULT('')  ,  ");
        sql.append("VALORPEDIDO    VARCHAR (15) NOT NULL DEFAULT('0')   )");
        return sql.toString();
    }

        public static String getCriateDadosPedido() {

            StringBuilder sql = new StringBuilder();
            sql.append("CREATE TABLE IF NOT EXISTS PEDIDOFECHADO(");
            sql.append("CODIGO         INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ,  ");
            sql.append("MESA         VARCHAR (70) NOT NULL DEFAULT('') ,  ");
            sql.append("NOMEPEDIDO   VARCHAR (70) NOT NULL DEFAULT('')  ,  ");
            sql.append("TIPOPEDIDO   VARCHAR (70) NOT NULL DEFAULT('')  ,  ");
            sql.append("VALORPEDIDO  VARCHAR (70) NOT NULL DEFAULT('')  )  ");
            return sql.toString();
        }

     }






