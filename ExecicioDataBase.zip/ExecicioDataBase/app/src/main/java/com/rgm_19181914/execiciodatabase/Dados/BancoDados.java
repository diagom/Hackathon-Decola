package com.rgm_19181914.execiciodatabase.Dados;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.renderscript.Script;

import androidx.annotation.Nullable;

public class BancoDados extends SQLiteOpenHelper {


    public BancoDados(@Nullable Context context) {
        super(context, "DADOS", null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(Scripts.getCriateDadosPedido());
        db.execSQL(Scripts.getCrietePedido());

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }
}
