package com.rgm_19181914.execiciodatabase;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.rgm_19181914.execiciodatabase.Dados.BancoDados;
import com.rgm_19181914.execiciodatabase.Dominio.Repositorio.ClienteRepositorio;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase conexao;
    private BancoDados bancodados;

    public ConstraintLayout p;
    public Button principal, sobrimesa, bebidas, verMesa, fecharPedido;
    public EditText mesa;

    ClienteRepositorio clienteRepositorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        p = (ConstraintLayout) findViewById(R.id.layoutP);
        principal = (Button) findViewById(R.id.BTNprincipal);
        sobrimesa = (Button) findViewById(R.id.BTNsobremesas);
        bebidas =(Button) findViewById(R.id.BTNbebidas);
        verMesa = (Button) findViewById(R.id.BTNverItens);
        fecharPedido = (Button) findViewById(R.id.BTNfecharPedido);
        mesa = findViewById(R.id.PTmesa);

        criarConecxao();


    }


    public void onClick(View view) {
        VerificarCampo();
        if (VerificarCampo()==true){

            clienteRepositorio.numeroMesa = (mesa.getText().toString());;


        Class classe=null;
        switch (view.getId()){
            case R.id.BTNprincipal: classe=PratoPrincipal.class;break;
            case R.id.BTNsobremesas: classe=Sobremesas.class;break;
            case R.id.BTNbebidas: classe=Bebidas.class;break;
            case R.id.BTNverItens: classe=Pedidos.class;break;
            case R.id.BTNfecharPedido: classe=PratoPrincipal.class;break;

        }
        if (classe != null){
            Intent my = new Intent(getApplicationContext(),classe);
            startActivity(my);
        }
        }


    }


    private void criarConecxao(){
        try{
            bancodados = new BancoDados(this);

            conexao = bancodados.getWritableDatabase();

            Snackbar.make(p,"Conexão Criada Com suceso!",Snackbar.LENGTH_LONG).setAction("ok",null).show();

        }catch (SQLException ex){
            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("",null);
            dlg.show();
        }
    }
    private boolean VerificarCampo(){
        boolean certo = true;

        String mesaVerificar = mesa.getText().toString() ;

        if(mesaVerificar.equals("")){
        certo = false;
            Toast.makeText(getApplicationContext(),"Preencha a mesa", Toast.LENGTH_SHORT).show();
        }



        return certo;
    }
}

